---
name: "box3api"
description: >
  Box3 / 神奇代码岛 JavaScript API 参考。包含所有 API 的属性、方法、
  事件说明和代码示例。
when_to_use: >
  当用户询问 API 用法、编写游戏脚本、实现游戏功能，或代码报错时使用。
  触发场景：实体创建与销毁、玩家控制与相机、方块放置与地形、数据存储与读写、
  计分与排行榜、伤害与战斗、粒子效果、关键帧动画、骨骼动作、UI 界面搭建、
  客户端音效与录音、服务端与客户端通讯、HTTP 请求、实时语音、
  物理碰撞与事件监听、天气与光照设置、世界查询与射线检测、调试报错或行为异常。
  以及用户提到以下任何名称时：world、player、voxels、storage、remoteChannel、
  http、rtc、ui、resources、screen、navigator、media、input、
  GameEntity、GameWorld、GamePlayerEntity、GameVoxels、GameDataStorage、
  GameAnimation、GameMotionController、ClientUI、ClientAudio、
  GameHttpAPI、GameRTC、GameBounds3、Sound。
arguments: [query]
argument-hint: "[API 名称或功能关键词]"
---

# Box3 API 参考

> 查询关键词：$query

## 文档结构

| 场景 | 读取文件 |
|------|---------|
| 快速查 API | `references/quick-reference.md` |
| 创建/查询/销毁实体 | `references/api-docs/game-entity.md` |
| 世界设置、天气、物理、聊天 | `references/api-docs/game-world.md` |
| 玩家控制、相机、输入、外观 | `references/api-docs/game-player.md` |
| 放置/获取/删除方块 | `references/api-docs/game-voxels.md` |
| 保存/读取数据 | `references/api-docs/game-data-storage.md` |
| 服务端↔客户端通讯 | `references/api-docs/remote-channel.md` |
| 制作游戏界面（UI） | `references/api-docs/client-ui.md` |
| 客户端音效播放 | `references/api-docs/client-audio.md` |
| 客户端录音 | `references/api-docs/client-media.md` |
| 屏幕适配、设备信息 | `references/api-docs/client-screen.md` + `references/api-docs/client-navigator.md` |
| 关键帧动画 | `references/api-docs/game-animation.md` |
| 模型骨骼动作 | `references/api-docs/game-motion-controller.md` |
| 外部 HTTP 请求 | `references/api-docs/game-http-api.md` |
| 语音通讯 | `references/api-docs/game-rtc.md` |
| 地图资源列表 | `references/api-docs/game-asset.md` |
| 向量/四元数/颜色/区域/事件Token | `references/api-docs/data-structures.md` |
| 代码报错、行为异常 | `references/gotchas.md` |

## Known Gotchas

- **事件 token 注销用 `.cancel()`，不是 `.dispose()`** → `references/gotchas.md#event-token-cancel`
- **storage 所有方法都是 async，必须 await** → `references/gotchas.md#storage-async`
- **createEntity 上限返回 null，不检查直接崩** → `references/gotchas.md#create-entity-null`
- **ambientSound 是 GameSoundEffect 对象，赋值用 `.sample =`** → `references/gotchas.md#ambient-sound-type`
- **UI 节点用 UiBox.create()，不是 new UiBox()** → `references/gotchas.md#ui-create-method`
- **GameQuaternion 构造函数参数顺序是 (w,x,y,z)** → `references/gotchas.md#quaternion-constructor-order`
- **voxelId 含旋转码，判断类型用 getVoxel 或 name()** → `references/gotchas.md#voxel-id-rotation`
- **entity.position[0] = x 不生效，必须整体赋值** → `references/gotchas.md#position-array-assign`

## 全局对象

| 对象 | 类型 | 用途 |
|------|------|------|
| `world` | GameWorld | 游戏世界主控制器 |
| `player` | GamePlayerEntity | 当前玩家 |
| `voxels` | GameVoxels | 方块操作 |
| `storage` | GameStorage | 数据存储 |
| `remoteChannel` | RemoteChannel | 客户端/服务端通讯 |
| `http` | GameHttpAPI / ClientHttp | HTTP 请求（仅白名单）|
| `rtc` | GameRTC | 实时语音 |
| `resources` | GameAssetListEntry | 地图资源列表 |
| `analytics` | GameAnalytics | 数据分析（企业用户）|
| `ui` | UiNode | 界面根节点（客户端）|
| `input` | InputSystem | 输入系统（客户端）|
| `media` | ClientMedia | 录音（客户端）|
| `screen` | ClientScreen | 屏幕事件（客户端）|
| `navigator` | ClientNavigator | 设备信息（客户端）|
| `screenWidth` | number | 屏幕宽度（客户端）|
| `screenHeight` | number | 屏幕高度（客户端）|
