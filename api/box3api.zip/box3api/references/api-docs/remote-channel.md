# RemoteChannel 速查表

## 概览

用于服务端与客户端之间的事件通信。服务端通过 `remoteChannel` 发送事件给玩家或广播给所有玩家；客户端通过 `remoteChannel` 接收服务端事件或发送事件到服务端。

## 服务端方法

| 方法 | 签名 | 说明 |
|------|------|------|
| `sendClientEvent()` | `sendClientEvent(entities, clientEvent): void` | 向指定玩家发送事件 |
| `broadcastClientEvent()` | `broadcastClientEvent(clientEvent): void` | 向所有玩家广播事件 |
| `onServerEvent()` | `onServerEvent(handler): EventToken` | 监听来自客户端的事件，返回 EventToken |

## 客户端方法

| 方法 | 签名 | 说明 |
|------|------|------|
| `sendServerEvent()` | `sendServerEvent(serverEvent: JSONValue): void` | 向服务端发送事件 |
| `onClientEvent()` | `onClientEvent(handler): EventToken` | 监听来自服务端的事件，返回 EventToken |

## 事件对象

### 服务端 onServerEvent 回调参数

```javascript
{
  entity: GamePlayerEntity,  // 发送者（玩家对象）
  args: JSONValue,           // 事件数据
  tick: number               // 事件发生时的游戏 tick
}
```

### 客户端 onClientEvent 回调参数

```javascript
JSONValue  // 服务端发送的事件数据
```

## 示例代码

```javascript
// === 服务端代码 ===

// 监听客户端消息
remoteChannel.onServerEvent((event) => {
  console.log('收到来自客户端:', event.entity.name, event.args);
  
  // 回复给该玩家
  remoteChannel.sendClientEvent(event.entity, {
    type: 'reply',
    message: 'Hello, ' + event.entity.name
  });
});

// 广播给所有玩家
world.onPlayerJoin((player) => {
  remoteChannel.broadcastClientEvent({
    type: 'player_joined',
    name: player.name
  });
});

// === 客户端代码 ===

// 监听服务端消息
remoteChannel.onClientEvent((data) => {
  console.log('收到服务端消息:', data);
  if (data.type === 'player_joined') {
    world.say(data.name + ' 进入游戏');
  }
});

// 发送给服务端
ui.onClick('attack_button', () => {
  remoteChannel.sendServerEvent({
    type: 'attack',
    targetId: target.id
  });
});
```

