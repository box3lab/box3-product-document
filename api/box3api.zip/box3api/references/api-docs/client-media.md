# ClientMedia（全局对象：media）

客户端音频录制 API。录制麦克风音频，生成 `audio/wav` 格式的 Blob 文件。

## 方法

| 方法 | 返回类型 | 说明 |
|------|---------|------|
| `startRecording()` | `Promise<void>` | 开始录音（首次会弹出麦克风权限请求） |
| `stopRecording()` | `Promise<Blob>` | 停止录音，返回 audio/wav 格式的 Blob |
| `playAudio(spec?)` | `Promise<void>` | 播放录音 |
| `stopPlayAudio()` | `void` | 停止播放录音 |

### playAudio 参数

```typescript
{
  blob?: Blob      // 音频 Blob（不传则播放最近录音）
  gain?: number    // 音量增益
}
```

## 示例

```javascript
// 开始录音
await media.startRecording();

// 3秒后停止录音并播放
setTimeout(async () => {
  const audioBlob = await media.stopRecording();
  // audioBlob 是 audio/wav 格式
  
  // 播放录音
  await media.playAudio({ blob: audioBlob, gain: 1.0 });
}, 3000);

// 停止播放
media.stopPlayAudio();
```
