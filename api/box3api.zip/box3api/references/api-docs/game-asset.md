# 游戏资源 API

## resources - 资源全局对象

全局对象：`resources`（GameAssetListEntry）

功能：列出地图中已加载的资源文件（模型、图片、音频等）。

### 方法

#### `resources.ls(path?): GameAssetListEntry[]`

列出资源树。

**参数：**
- `path` (可选)：资源类别
  - `'snow'` — 雪花纹理
  - `'mesh'` — 模型
  - `'picture'` — 图片
  - `'audio'` — 音频
  - `'lut'` — 颜色滤镜
  - 不传则返回全部资源树

**返回值：** GameAssetListEntry 数组

### GameAssetListEntry 接口

```typescript
{
  path: string,       // 资产完整路径，按目录拆分
  type: GameAssetType
}
```

### GameAssetType 枚举

| 值 | 说明 |
|-----|------|
| `VOXEL_MESH` | 模型 |
| `DIRECTORY` | 文件夹 |
| `COLOR_LUT` | 颜色滤镜 |
| `JS_SCRIPT` | 脚本 |
| `IMAGE` | 图片 |
| `PARTICLE_TEXTURE` | 雪花纹理 |
| `SOUND` | 音频 |
| `PICTURE` | 图片 |

### 使用示例

```javascript
// 列出所有音频资源
const audios = resources.ls('audio');
audios.forEach(item => {
  console.log(item.type, item.path);
});

// 列出所有模型资源
const meshes = resources.ls('mesh');

// 列出全部资源
const all = resources.ls();
all.forEach(item => {
  if (item.type === 'SOUND') {
    console.log('音频:', item.path);
  }
});

// 获取资源路径，用于创建实体
const mesh = resources.ls('mesh').find(r => r.path.includes('flower'));
if (mesh) {
  world.createEntity({ mesh: mesh.path, position: [0, 5, 0] });
}
```
