# GameHttpApi 速查表

## 全局方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `http.fetch(url, options?)` | `string, GameHttpFetchRequestOptions?` | `Promise<GameHttpFetchResponse>` | 发起 HTTP 请求 |

## GameHttpFetchRequestOptions 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `method` | `'GET' \| 'POST' \| 'PUT' \| 'DELETE' \| 'PATCH' \| 'HEAD'` | `'GET'` | HTTP 方法 |
| `headers` | `{ [name: string]: string \| string[] }` | `{}` | 请求头 |
| `body` | `string \| ArrayBuffer` | `undefined` | 请求体 |
| `timeout` | `number` | 默认超时 | 超时毫秒数 |

## GameHttpFetchResponse 方法

| 方法 | 返回值 | 说明 |
|------|--------|------|
| `json()` | `Promise<any>` | 解析为 JSON |
| `text()` | `Promise<string>` | 解析为纯文本 |
| `arrayBuffer()` | `Promise<ArrayBuffer>` | 解析为二进制 |

## GameHttpFetchResponse 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `ok` | `boolean` | 状态码 200-299 时为 true |
| `status` | `number` | HTTP 状态码 |
| `statusText` | `string` | 状态描述文本 |

## 示例代码

```javascript
// GET 请求获取 JSON 数据
const res = await http.fetch('https://api.example.com/data');
if (res.ok) {
  const data = await res.json();
  world.say('得到数据: ' + JSON.stringify(data));
} else {
  world.say('请求失败: HTTP ' + res.status);
}

// POST 请求发送 JSON
const res = await http.fetch('https://api.example.com/submit', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ player: player.name, score: 100 })
});
const result = await res.json();

// PUT 请求更新数据
const res = await http.fetch('https://api.example.com/user/123', {
  method: 'PUT',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ level: 50, gold: 1000 })
});

// 带超时的请求
const res = await http.fetch('https://api.example.com/slow', {
  timeout: 5000  // 5秒超时
});

// 完整错误处理
try {
  const res = await http.fetch('https://api.example.com/data');
  if (!res.ok) {
    throw new Error('HTTP ' + res.status + ': ' + res.statusText);
  }
  const data = await res.json();
  world.say(JSON.stringify(data));
} catch (err) {
  world.say('请求异常: ' + err.message);
}

// 发送 FormData（需手动序列化）
const body = 'username=player&level=50';
const res = await http.fetch('https://api.example.com/form', {
  method: 'POST',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  body: body
});

// 获取二进制数据
const res = await http.fetch('https://api.example.com/image.png');
const buffer = await res.arrayBuffer();
```


---

## 客户端 http（ClientHttp）

**客户端脚本**中同样使用 `http` 全局对象，但 API 略有不同：

```typescript
// 客户端：http.fetch 返回标准 Web API Response 对象
const res = await http.fetch(url, options?);
// options 为标准 RequestInit（与浏览器 fetch 一致）
// res 为标准 Web API Response（不是服务端的 GameHttpFetchResponse）
```

```javascript
// 客户端 http 用法（与服务端几乎相同）
const res = await http.fetch('https://api.example.com/data');
const data = await res.json();

// POST
const res = await http.fetch('https://api.example.com/submit', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ score: 100 })
});
```

⚠️ 服务端和客户端都只支持白名单内的 URL。
