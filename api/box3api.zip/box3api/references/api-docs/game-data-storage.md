# GameStorage 速查表

## 概览

全局对象 `storage` 提供持久化数据存储。分为单地图存储和组地图（主副图）存储两种空间，均支持异步操作。

## 方法

| 方法 | 签名 | 说明 |
|------|------|------|
| `getDataStorage()` | `getDataStorage(name: string): DataStorage` | 获取单地图存储空间 |
| `getGroupStorage()` | `getGroupStorage(name: string): DataStorage` | 获取组地图存储空间 |

## DataStorage 对象方法

所有方法均为异步（返回 Promise）。

| 方法 | 签名 | 说明 |
|------|------|------|
| `set()` | `set(key, value): Promise<void>` | 设置键值对 |
| `get()` | `get(key): Promise<ReturnValue>` | 获取值（不存在返回 undefined） |
| `update()` | `update(key, handler): Promise<void>` | 原子更新，handler 接收旧值返回新值 |
| `remove()` | `remove(key): Promise<ReturnValue>` | 删除键值对 |
| `increment()` | `increment(key, value?): Promise<number>` | 原子递增（默认 +1），返回新值 |
| `list()` | `list(options): Promise<QueryList>` | 批量获取，options 含 cursor/pageSize/prefix |
| `destroy()` | `destroy(): Promise<void>` | 删除整个存储空间 |

## DataStorage 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `key` | string（只读） | 存储空间名称 |

## 示例代码

```javascript
// 初始化存储
const userStorage = storage.getDataStorage('users');

// 保存玩家数据
await userStorage.set('player_001', {
  score: 100,
  level: 5,
  lastLogin: Date.now()
});

// 读取数据
const data = await userStorage.get('player_001');
if (data !== undefined) {
  world.say('Score: ' + data.score);
}

// 原子递增（排行榜场景）
await userStorage.increment('total_games');
await userStorage.increment('player_001_kills', 3);

// 原子更新
await userStorage.update('player_001', (prev) => ({
  ...prev,
  score: (prev?.score || 0) + 10
}));

// 批量获取
const result = await userStorage.list({ prefix: 'player_', pageSize: 20 });
result.items.forEach(item => console.log(item.key, item.value));
```

