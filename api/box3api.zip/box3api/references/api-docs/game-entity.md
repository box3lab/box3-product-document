# GameEntity - 属性速查表


| 属性 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `id` | string | 实体唯一标识 | `entity.id` |
| `position` | [x,y,z] | 位置 | `entity.position = [0,5,0]` |
| `meshOrientation` | Quaternion | 旋转 | `entity.meshOrientation = quaternion` |
| `meshScale` | [x,y,z] | 缩放 | `entity.meshScale = [1,1,1]` |
| `meshColor` | Color | 颜色 | `entity.meshColor = 0xFF0000` |
| `meshInvisible` | boolean | 隐形 | `entity.meshInvisible = false` |
| `meshEmissive` | 0-1 | 发光 | `entity.meshEmissive = 0.5` |
| `meshMetalness` | 0-1 | 金属感 | `entity.meshMetalness = 0.8` |
| `meshShininess` | 0-1 | 反光 | `entity.meshShininess = 0.5` |
| `mass` | number | 质量 | `entity.mass = 1` |
| `velocity` | [x,y,z] | 速度 | `entity.velocity = [0,0,5]` |
| `gravity` | boolean | 重力 | `entity.gravity = true` |
| `collides` | boolean | 碰撞 | `entity.collides = true` |
| `fixed` | boolean | 固定 | `entity.fixed = false` |
| `friction` | 0-1 | 摩擦力 | `entity.friction = 0.5` |
| `restitution` | 0-1 | 弹性 | `entity.restitution = 0` |
| `bounds` | GameVector3（只读）| 碰撞包围盒尺寸，默认(1,1,1) | `entity.bounds` |
| `hp` | number | 生命值 | `entity.hp = 100` |
| `maxHp` | number | 最大HP | `entity.maxHp = 100` |
| `enableDamage` | boolean | 可伤害 | `entity.enableDamage = true` |
| `showHealthBar` | boolean | 显示HP条 | `entity.showHealthBar = true` |
| `enableInteract` | boolean | 可交互 | `entity.enableInteract = true` |
| `interactRadius` | number | 交互范围 | `entity.interactRadius = 3` |
| `interactHint` | string | 交互提示 | `entity.interactHint = "按E交互"` |
| `particleRate` | number | 粒子速率 | `entity.particleRate = 10` |
| `particleLimit` | number | 粒子上限 | `entity.particleLimit = 100` |
| `tags()` | string[] | 标签列表（方法，需加括号）| `entity.tags()` |
| `destroyed` | boolean | 已销毁 | `if (entity.destroyed) {...}` |
| `entityContacts` | Entity[] | 实体碰撞 | `entity.entityContacts` |
| `voxelContacts` | Contact[] | 方块碰撞 | `entity.voxelContacts` |
| `fluidContacts` | Contact[] | 液体接触 | `entity.fluidContacts` |

## 方法速查

| 方法 | 说明 | 示例 |
|------|------|------|
| `lookAt(pos)` | 面向位置 | `entity.lookAt(player.position)` |
| `animate(frames, opts)` | 创建动画 | `entity.animate([{...}])` |
| `getAnimations()` | 获取动画 | `entity.getAnimations()` |
| `sound(opts)` | 播放声音 | `entity.sound({name: 'boom'})` |
| `say(msg)` | 说话 | `entity.say('Hello!')` |
| `addTag(tag)` | 添加标签 | `entity.addTag('boss')` |
| `removeTag(tag)` | 移除标签 | `entity.removeTag('boss')` |
| `hasTag(tag)` | 检查标签 | `if (entity.hasTag('enemy'))` |
| `hurt(dmg)` | 造成伤害 | `entity.hurt(10)` |
| `destroy()` | 销毁 | `entity.destroy()` |

## 事件速查

| 事件 | 触发条件 |
|------|---------|
| `onClick(cb)` | 玩家点击实体 |
| `onInteract(cb)` | 玩家按E互动 |
| `onEntityContact(cb)` | 与实体碰撞开始 |
| `onEntitySeparate(cb)` | 与实体碰撞结束 |
| `onVoxelContact(cb)` | 与方块碰撞开始 |
| `onVoxelSeparate(cb)` | 与方块碰撞结束 |
| `onFluidEnter(cb)` | 进入液体 |
| `onFluidLeave(cb)` | 离开液体 |
| `onTakeDamage(cb)` | 受伤 |
| `onDie(cb)` | 死亡 |
| `onDestroy(cb)` | 销毁时 |

## 完整示例

### 创建敌人
```javascript
const enemy = world.createEntity({
  mesh: 'cube',
  position: [5, 2, 0],
  meshColor: 0xFF0000,
  hp: 30,
  maxHp: 30,
  enableDamage: true,
  showHealthBar: true,
  mass: 1,
  gravity: true
});

enemy.addTag('enemy');
enemy.onTakeDamage((event) => {
  world.say('HP: ' + enemy.hp);
});
enemy.onDie(() => {
  world.say('Enemy defeated!');
});
```

### 创建交互物体
```javascript
const chest = world.createEntity({
  mesh: 'cube',
  position: [0, 1, 10],
  meshColor: 0x8B4513,
  fixed: true
});

chest.customName = '宝箱';
chest.enableInteract = true;
chest.interactRadius = 3;
chest.interactHint = '按 E 打开';

chest.onInteract((event) => {
  world.say(event.player.name + ' 打开了宝箱！');
  chest.destroy();
});
```

### 创建移动平台
```javascript
const platform = world.createEntity({
  mesh: 'cube',
  position: [0, 5, 0],
  meshScale: [2, 0.5, 2],
  fixed: true
});

platform.animate([
  { duration: 2000, position: [0, 5, 0] },
  { duration: 2000, position: [10, 5, 0] },
  { duration: 2000, position: [10, 8, 0] },
  { duration: 2000, position: [0, 8, 0] }
], { repeat: -1 });
```

