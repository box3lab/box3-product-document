# GameRTC 速查表

## 全局方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `rtc.createChannel()` | - | `RtcChannel` | 创建语音通道 |

## RtcChannel 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `destroy()` | - | `void` | 销毁通道，断开所有连接 |
| `getPlayers()` | - | `GamePlayerEntity[]` | 获取通道内所有玩家 |
| `add(player)` | `GamePlayerEntity` | `void` | 添加玩家到通道 |
| `remove(player)` | `GamePlayerEntity` | `void` | 从通道移除玩家 |
| `getMicrophonePermission(player)` | `GamePlayerEntity` | `Promise<boolean>` | 请求玩家麦克风权限 |
| `publishMicrophone(player)` | `GamePlayerEntity` | `void` | 允许玩家开麦 |
| `unpublish(player)` | `GamePlayerEntity` | `void` | 关闭玩家麦克风 |
| `getVolume(player)` | `GamePlayerEntity` | `number` | 获取玩家音量（0.0-1.0） |
| `setVolume(player, volume)` | `GamePlayerEntity, number` | `void` | 设置玩家音量 |

## RtcChannel 属性

| 属性 | 类型 | 说明 | 读写 |
|------|------|------|------|
| `players` | `GamePlayerEntity[]` | 通道内的所有玩家（同 getPlayers()） | 只读 |

## 示例代码

```javascript
// 为所有玩家创建语音房间
const channel = rtc.createChannel();

world.onPlayerJoin((player) => {
  channel.add(player);
  channel.getMicrophonePermission(player);
});

world.onPlayerLeave((player) => {
  channel.remove(player);
});

// 获取通道内的玩家列表
const players = channel.getPlayers();
world.say('房间内有 ' + players.length + ' 人');

// 调整单个玩家音量
channel.setVolume(player, 0.5);  // 50% 音量

// 静音玩家
channel.setVolume(player, 0);

// 恢复音量
channel.setVolume(player, 1.0);

// 查询当前音量
const vol = channel.getVolume(player);
world.say(player.name + ' 的音量: ' + (vol * 100).toFixed(0) + '%');

// 关闭所有玩家的麦克风
channel.getPlayers().forEach(p => channel.unpublish(p));

// 重新允许特定玩家说话
channel.publishMicrophone(player);

// 销毁通道（所有玩家断开）
channel.destroy();

// 权限请求处理
world.onPlayerJoin((player) => {
  channel.add(player);
  channel.getMicrophonePermission(player).then(allowed => {
    if (allowed) {
      channel.publishMicrophone(player);
    } else {
      world.say(player.name + ' 拒绝了语音权限');
    }
  });
});

// 多个通道管理
const voiceChannel = rtc.createChannel();
const commandChannel = rtc.createChannel();

world.onPlayerJoin((player) => {
  voiceChannel.add(player);
  commandChannel.add(player);
});
```

