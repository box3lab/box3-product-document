# ClientUI - 游戏界面

客户端脚本中使用。全局对象：`ui`（UiNode 根节点）、`input`（InputSystem）、`screenWidth`、`screenHeight`。

## 创建节点

```javascript
// ⚠️ 使用静态方法 create()，不是 new
const box    = UiBox.create();
const text   = UiText.create();
const img    = UiImage.create();
const inp    = UiInput.create();
const scroll = UiScrollBox.create();
```

## 挂载节点

```javascript
// 必须设置 parent 才会被渲染
box.parent  = ui;        // 挂到根节点
text.parent = box;       // 挂到另一个节点
text.parent = undefined; // 取消挂载
```

---

## UiNode（所有节点公共属性）

| 属性 | 类型 | 说明 |
|------|------|------|
| `name` | string | 节点标识符（可重复）|
| `parent` | UiNode \| undefined | 父节点（为空则不渲染）|
| `children` | ReadonlyArray\<UiNode\>（只读）| 子节点列表 |
| `events` | EventEmitter | 事件管理器 |
| `uiScale` | UiScale \| undefined | 等比缩放 |

**方法：**
```javascript
node.findChildByName('btn_start')  // 按名称找子节点，返回 UiNode | undefined
```

---

## UiRenderable（可渲染节点公共属性）

| 属性 | 类型 | 说明 |
|------|------|------|
| `visible` | boolean | 可见性（默认 true）|
| `zIndex` | number | 渲染层级（默认 1）|
| `anchor` | Vec2（只读）| 锚点 (0-1)，默认 {x:0.5, y:0.5} |
| `position` | Coord2（只读）| 相对父节点的位置 |
| `size` | Coord2（只读）| 节点尺寸 |
| `rotation` | number | 旋转角度（-179 到 180，默认 0）|
| `backgroundColor` | Vec3（只读）| 背景颜色 |
| `backgroundOpacity` | number | 背景透明度（0-1，默认 1）|
| `autoResize` | 'NONE'\|'X'\|'Y'\|'XY' | 自动调整尺寸（默认 'NONE'）|
| `pointerEventBehavior` | PointerEventBehavior | 鼠标事件响应方式（默认 ENABLE）|

**PointerEventBehavior 枚举：**

| 值 | 说明 |
|----|------|
| `DISABLE_AND_BLOCK_PASS_THROUGH` | 不响应，且阻止后方元素响应 |
| `DISABLE` | 不响应 |
| `BLOCK_PASS_THROUGH` | 阻止后方元素响应（自身不响应）|
| `ENABLE` | 正常响应（默认）|

---

## UiText（文本节点）

| 属性 | 类型 | 说明 |
|------|------|------|
| `textContent` | string | 文本内容（默认 'Text'）|
| `richText` | boolean | 支持富文本（默认 false）|
| `textFontSize` | number | 字号（默认 14）|
| `textColor` | Vec3（只读）| 文本颜色 |
| `textXAlignment` | 'Center'\|'Left'\|'Right' | 水平对齐（默认 'Center'）|
| `textYAlignment` | 'Center'\|'Top'\|'Bottom' | 垂直对齐（默认 'Center'）|
| `autoWordWrap` | boolean | 自动换行（默认 false）|
| `textLineHeight` | number | 行高（默认 1.2）|
| `textStrokeColor` | Vec3（只读）| 描边颜色 |
| `textStrokeOpacity` | number | 描边透明度（默认 1）|
| `textStrokeThickness` | number | 描边粗细 0-25（默认 0）|
| `textFontFamily` | UITextFontFamily | 字体样式 |

---

## UiImage（图片节点）

| 属性 | 类型 | 说明 |
|------|------|------|
| `image` | string | 图片路径或 URL（默认 ''）|
| `imageOpacity` | number | 图片透明度（默认 1）|
| `imageDisplayMode` | ImageDisplayMode | 图片显示模式（默认 Fill）|
| `complete` | boolean（只读）| 图片是否加载完毕 |

**ImageDisplayMode 枚举：**

| 值 | 说明 |
|----|------|
| `ImageDisplayMode.Fill` | 铺满（默认，可能变形）|
| `ImageDisplayMode.Contain` | 等比铺满（不裁剪）|
| `ImageDisplayMode.Cover` | 等比截取（超出裁剪）|
| `ImageDisplayMode.None` | 原始尺寸居中 |

---

## UiInput（输入框）继承自 UiText

| 属性 | 类型 | 说明 |
|------|------|------|
| `placeholder` | string | 占位提示文字（默认 'Type something here'）|
| `placeholderColor` | Vec3（只读）| 占位文字颜色 |
| `placeholderOpacity` | number（只读）| 占位文字透明度（默认 1）|
| `isFocus` | boolean（只读）| 是否处于焦点状态 |

**方法：**
```javascript
inp.focus()         // 聚焦
inp.blur(): string  // 失焦，返回当前输入值
```

---

## UiScrollBox（滚动容器）

| 属性 | 类型 | 说明 |
|------|------|------|
| `scrollPosition` | Vec2（只读）| 滚动位置，{x:0, y:0} 为顶部/左侧 |

---

## 事件监听

通过 `node.events.add(type, handler)` 监听：

| 节点类型 | 事件名 | 说明 |
|---------|--------|------|
| 所有可渲染节点 | `'pointerdown'` | 鼠标/触摸按下（受 pointerEventBehavior 影响）|
| 所有可渲染节点 | `'pointerup'` | 鼠标/触摸抬起 |
| UiImage | `'load'` | 图片加载完毕 |
| UiInput | `'focus'` | 输入框获得焦点 |
| UiInput | `'blur'` | 输入框失去焦点 |

```javascript
// 节点点击（用 pointerdown，不是 onClick）
btn.events.add('pointerdown', ({ target }) => {
  world.say('按下了按钮');
});

// 图片加载完成
img.events.add('load', (event) => {
  console.log('已加载:', event.target.complete);
});

// 输入框焦点
inp.events.add('focus', () => { console.log('开始输入'); });
inp.events.add('blur', () => { console.log('结束输入'); });

// 全局监听所有元素
input.uiEvents.add('pointerdown', ({ target }) => {
  console.log('点击了:', target.name);
});
```

---

## input（InputSystem）- 鼠标指针控制

```javascript
input.lockPointer()    // 隐藏鼠标指针（游戏内鼠标锁定）
input.unlockPointer()  // 显示鼠标指针

// 监听指针锁定状态
input.pointerLockEvents.add('pointerlockchange', ({ isLocked }) => {
  console.log('指针锁定:', isLocked);
});
```

---

## 完整示例

```javascript
// 创建 HUD 面板
const panel = UiBox.create();
panel.parent = ui;
panel.backgroundOpacity = 0.7;

const scoreText = UiText.create();
scoreText.parent = panel;
scoreText.textContent = 'Score: 0';
scoreText.textFontSize = 24;
scoreText.textXAlignment = 'Center';

function updateScore(score) {
  scoreText.textContent = 'Score: ' + score;
}

// 创建交互按钮
const btn = UiImage.create();
btn.parent = ui;
btn.image = 'picture/attack_btn.png';
btn.pointerEventBehavior = PointerEventBehavior.ENABLE;
btn.events.add('pointerdown', () => {
  world.say('攻击！');
});

// 创建输入框
const nameInput = UiInput.create();
nameInput.parent = ui;
nameInput.placeholder = '输入名字';
nameInput.events.add('blur', () => {
  const value = nameInput.blur();
  world.say('输入了: ' + value);
});

// 屏幕自适应（监听 screen resize）
screen.events.add('resize', ({ screenWidth: w, screenHeight: h }) => {
  if (!panel.uiScale) panel.uiScale = UiScale.create();
  panel.uiScale.scale = w < 1300 ? w / 1300 : 1;
});
scaleUI(screenWidth, screenHeight);
```
