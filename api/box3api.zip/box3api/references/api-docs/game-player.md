# GamePlayerEntity 速查表

通过全局 `player` 对象访问，等同于 `world.player`。继承 GameEntity 所有属性/方法/事件。

## 基础标识

| 属性 | 类型 | 说明 |
|------|------|------|
| `name` | string | 玩家昵称（只读） |
| `id` | string | 玩家 ID（只读） |
| `userId` | string | 用户 ID |
| `boxId` | string | Box ID (3-15字符) |
| `userKey` | string | 唯一识别码 (16字符) |
| `avatar` | string | 头像 URL |
| `url` | string | 进入地图时的 URL |
| `data` | Storage | 玩家数据存储 |

## 控制属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `enableJump` | boolean | 能否跳跃（默认 true）|
| `enableDoubleJump` | boolean | 能否二段跳（默认 false）|
| `canFly` | boolean | 能否飞行 |
| `spectator` | boolean | 观察者模式 |
| `enableAction0` | boolean | 启用左键/虚拟A键 |
| `enableAction1` | boolean | 启用右键/虚拟B键 |
| `walkSpeed` | number | 行走速度 |
| `runSpeed` | number | 跑步速度 |
| `jumpPower` | number | 跳跃力度 |
| `flySpeed` | number | 飞行速度 |
| `swimSpeed` | number | 游泳速度 |
| `crouchSpeed` | number | 蹲行速度 |
| `disableInputDirection` | GameInputDirection | 禁用摇杆方向 |
| `reverseInputDirection` | GameInputDirection | 反转指定方向摇杆 |
| `swapInputDirection` | boolean | 交换方向键（开启后前后左右交换）|
| `facingDirection` | GameVector3（只读）| 玩家朝向 |
| `movementBounds` | GameBounds3\|null | 活动范围限制（超出传送回出生点）|
| `moveState` | GamePlayerMoveState（只读）| 当前运动状态 |

## 外观属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `color` | GameRGBColor | 玩家颜色 |
| `emissive` | number | 发光度 (0-1) |
| `invisible` | boolean | 是否隐身 |
| `showName` | boolean | 是否显示名字 |
| `showIndicator` | boolean | 是否显示标记 |
| `scale` | number | 模型缩放 |
| `metalness` | number | 金属感 (0-1) |
| `shininess` | number | 反光度 (0-1) |

## 相机属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `cameraMode` | string | `'FOLLOW'`/`'FPS'`/`'FIXED'`/`'RELATIVE'` |
| `cameraEntity` | GameEntity\|null | 跟随的实体（FPS/FOLLOW 模式） |
| `cameraPosition` | GameVector3 | 相机位置（FIXED/RELATIVE 模式） |
| `cameraTarget` | GameVector3 | 相机目标点（FIXED/RELATIVE 模式） |
| `cameraFovY` | number | 垂直视场角（度） |
| `cameraDistance` | number | 相机与目标距离（FOLLOW 模式） |
| `enable3DCursor` | boolean | 启用 3D 光标 |
| `freezedForwardDirection` | GameVector3\|null | 锁定朝向 |

## 战斗属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `dead` | boolean | 是否死亡（hp<=0 时倒地，只读） |
| `spawnPoint` | GameVector3 | 复活出生点 |

## 音效属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `music` | string | 玩家专属背景音乐 |
| `jumpSound` | string | 跳跃音效 |
| `landSound` | string | 落地音效 |
| `spawnSound` | string | 重生音效 |
| `stepSound` | string | 脚步音效 |

## 特有方法

| 方法 | 说明 |
|------|------|
| `getDirection()` | 获取相机朝向（GameVector3） |
| `startWalking(dir)` | 强制开始移动 |
| `stopWalking()` | 停止移动 |

## 数据存储

```javascript
// 保存 / 读取 / 删除（会话级持久化）
player.data.set('score', 100);
const score = player.data.get('score');
player.data.remove('score');
```

## 控制示例

```javascript
// 禁止跳跃
player.enableJump = false;

// 限制活动范围
player.movementBounds = new GameBounds3(
  new GameVector3(0, 0, 0),
  new GameVector3(100, 50, 100)
);

// 设置复活点
player.spawnPoint = new GameVector3(10, 5, 10);
```

## 相机示例

```javascript
// 固定俯视视角
player.cameraMode = 'FIXED';
player.cameraPosition = new GameVector3(0, 50, 0);
player.cameraTarget = new GameVector3(0, 0, 0);

// 第一人称
player.cameraMode = 'FPS';

// 跟随实体
player.cameraMode = 'FOLLOW';
player.cameraEntity = someEntity;
player.cameraDistance = 5;

// 瞄准缩放
const origFov = player.cameraFovY;
player.cameraFovY = origFov / 2;
```

## 外观示例

```javascript
// 颜色 / 发光 / 隐身
player.color = new GameRGBColor(1, 0, 0);
player.emissive = 0.5;
player.invisible = true;
player.scale = 1.5;
```

## 伤害 / 死亡示例

```javascript
player.onTakeDamage((event) => {
  world.say('HP: ' + player.hp + '/' + player.maxHp);
});

player.onDie(() => {
  setTimeout(() => {
    player.hp = player.maxHp;
    player.position = [0, 10, 0];
  }, 3000);
});
```

## 碰撞示例

```javascript
// 检测是否在地面
let onGround = false;
player.onVoxelContact(() => { onGround = true; });
player.onVoxelSeparate(() => { onGround = false; });

// 被敌人击中
player.onEntityContact((event) => {
  if (event.entity.hasTag('enemy')) player.hurt(5);
});
```
