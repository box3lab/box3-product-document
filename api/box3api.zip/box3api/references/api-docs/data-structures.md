# 数据结构 API

## GameVector3 - 3D 向量

```typescript
declare class GameVector3 {
  constructor(x: number, y: number, z: number);
  x: number;
  y: number;
  z: number;
}
```

```javascript
// 创建并使用
const pos = new GameVector3(0, 5, 0);
entity.position = [pos.x, pos.y, pos.z];

// 数组形式也可以直接赋值
entity.position = [1, 2, 3];
entity.velocity = [0, 5, 0];

// 读取分量
const x = entity.position[0];
const y = entity.position[1];
const z = entity.position[2];
```

---

## GameQuaternion - 四元数（旋转）

```typescript
// ⚠️ 注意：构造函数参数顺序是 w, x, y, z（w 在前）
declare class GameQuaternion {
  constructor(w: number, x: number, y: number, z: number);
  w: number; x: number; y: number; z: number;

  // 静态方法
  static fromEuler(x: number, y: number, z: number): GameQuaternion;  // 旋转顺序 YZX
  static fromAxisAngle(axis: GameVector3, rad: number): GameQuaternion;
  static rotationBetween(a: GameVector3, b: GameVector3): GameQuaternion;

  // 实例方法
  set(w, x, y, z): GameQuaternion;
  clone(): GameQuaternion;
  copy(v: GameQuaternion): GameQuaternion;
  mul(q: GameQuaternion): GameQuaternion;    // 旋转组合（不是 multiply）
  inv(): GameQuaternion;                     // 逆旋转（不是 inverse）
  normalize(): GameQuaternion;
  dot(q: GameQuaternion): number;
  slerp(q: GameQuaternion, n: number): GameQuaternion;
  angle(q: GameQuaternion): number;
  equals(v: GameQuaternion): boolean;
  toString(): string;
}
```

```javascript
// 恒等旋转（无旋转）：w=1, x=y=z=0
entity.meshOrientation = new GameQuaternion(1, 0, 0, 0);

// 从欧拉角创建（弧度，旋转顺序 YZX）
entity.meshOrientation = GameQuaternion.fromEuler(0, Math.PI / 2, 0);  // Y轴转90°

// 度数转弧度
const deg = 45;
entity.meshOrientation = GameQuaternion.fromEuler(0, deg * Math.PI / 180, 0);

// 旋转组合（用 mul，不是 multiply）
const q1 = GameQuaternion.fromEuler(Math.PI / 4, 0, 0);
const q2 = GameQuaternion.fromEuler(0, Math.PI / 2, 0);
entity.meshOrientation = q1.mul(q2);

// 从轴角创建
entity.meshOrientation = GameQuaternion.fromAxisAngle(
  new GameVector3(0, 1, 0),  // Y轴
  Math.PI / 2                // 90度
);

// 球形插值（动画过渡）
const start = GameQuaternion.fromEuler(0, 0, 0);
const end = GameQuaternion.fromEuler(0, Math.PI, 0);
entity.meshOrientation = start.slerp(end, 0.5);  // 中间旋转状态

// 面向目标（推荐用 lookAt，更简单）
entity.lookAt(player.position);
```

---

## 颜色

```javascript
// 十六进制（推荐）
entity.meshColor = 0xFF0000;   // 红
entity.meshColor = 0x00FF00;   // 绿
entity.meshColor = 0x0000FF;   // 蓝
entity.meshColor = 0xFFFFFF;   // 白
entity.meshColor = 0x000000;   // 黑

// 数组 [R, G, B]（0-255）
entity.meshColor = [255, 0, 0];

// 数组 [R, G, B, A]（0-1）
entity.meshColor = [1, 0, 0, 0.5];   // 半透明红
```

---

## 数组类型速查

| 属性 | 格式 | 示例 |
|------|------|------|
| `position` | [x, y, z] | `[0, 5, 0]` |
| `velocity` | [vx, vy, vz] | `[0, 10, 0]` |
| `meshScale` | [sx, sy, sz] | `[1, 1, 1]` |
| `meshOffset` | [ox, oy, oz] | `[0, 0.5, 0]` |
| `meshOrientation` | [x, y, z, w] 四元数 | `[0, 0, 0, 1]` |
| `particleAcceleration` | [ax, ay, az] | `[0, -10, 0]` |

---

## 选择器语法

用于 `world.querySelector()` / `world.querySelectorAll()`。

```javascript
world.querySelector('[id=npc_001]')           // 按 ID
world.querySelectorAll('[tag=enemy]')          // 按标签
world.querySelectorAll('[tag=enemy][tag=boss]') // 多标签（AND）
world.querySelectorAll('[tag!=player]')         // 排除标签
```

---

## createEntity 参数

```typescript
world.createEntity({
  mesh?: string,           // 形状 hash（需提前在编辑器加载）
  position?: [x, y, z],
  meshOrientation?: GameQuaternion,
  meshScale?: [x, y, z],
  meshColor?: Color,
  meshInvisible?: boolean,
  meshEmissive?: number,   // 0-1
  meshMetalness?: number,  // 0-1
  mass?: number,           // 0 = 固定
  velocity?: [x, y, z],
  gravity?: boolean,
  collides?: boolean,
  fixed?: boolean,
  friction?: number,       // 0-1
  restitution?: number,    // 0-1
  bounds?: number,
  hp?: number,
  maxHp?: number,
  enableDamage?: boolean,
  showHealthBar?: boolean,
  enableInteract?: boolean,
  interactRadius?: number,
  interactHint?: string,
  interactColor?: Color,
})
```

---

## 动画关键帧

```typescript
entity.animate([
  {
    duration: number,        // 时长（毫秒）
    position?: [x, y, z],
    meshOrientation?: GameQuaternion,
    meshScale?: [x, y, z],
    meshColor?: Color,
    meshEmissive?: number,
  },
  // 更多帧...
], {
  repeat?: number,           // -1 = 无限循环，0 = 播一次
  delay?: number,
  direction?: 'normal' | 'reverse' | 'alternate',
})
```

---

## 事件回调参数类型

| 事件 | 参数字段 |
|------|---------|
| `onClick(cb)` | `{ player, position: [x,y,z] }` |
| `onInteract(cb)` | `{ player }` |
| `onEntityContact(cb)` | `{ entity, normal?: [x,y,z] }` |
| `onVoxelContact(cb)` | `{ voxelId, position, normal }` |
| `onTakeDamage(cb)` | `{ damage, attacker? }` |
| `onDie(cb)` | `{ attacker? }` |
| `onChat(cb)` | `{ player, message }` （world 上）|
| `onServerEvent(cb)` | `{ entity, args, tick }` （remoteChannel 上）|

---

## GameBounds3 - 三维区域

表示一个由两个对角点确定的 3D 包围盒。

```typescript
declare class GameBounds3 {
  constructor(lo: GameVector3, hi: GameVector3);
  lo: GameVector3;  // 低处顶点（min）
  hi: GameVector3;  // 高处顶点（max）

  static fromPoints(...points: GameVector3[]): GameBounds3;
  set(lox, loy, loz, hix, hiy, hiz): GameBounds3;
  contains(point: GameVector3): boolean;
  intersects(other: GameBounds3): boolean;
}
```

```javascript
// 创建区域
const bounds = new GameBounds3(
  new GameVector3(0, 0, 0),    // lo：最小角
  new GameVector3(10, 5, 10)   // hi：最大角
);

// 从多个点创建包围盒
const bounds2 = GameBounds3.fromPoints(
  new GameVector3(1, 2, 3),
  new GameVector3(7, 8, 9)
);

// 检查点是否在区域内
if (bounds.contains(player.position)) {
  world.say('玩家在区域内！');
}

// 限制玩家活动范围
player.movementBounds = bounds;
```

---

## GameEventHandlerToken - 事件 Token

所有 `onXxx()` 事件监听方法的返回值。用于管理事件监听的生命周期。

| 方法 | 说明 |
|------|------|
| `cancel()` | 取消（注销）该事件监听 |
| `resume()` | 恢复被取消的事件监听 |
| `active(): boolean` | 检查该监听是否处于活动状态 |

```javascript
// 保存 token（重要！不保存就无法取消）
const token = entity.onClick(() => {
  world.say('被点击了');
});

// 取消监听
token.cancel();

// 恢复监听
token.resume();

// 检查是否活跃
if (token.active()) {
  console.log('监听器仍在运行');
}
```

⚠️ 注销方法是 `cancel()`，不是 `dispose()`。

---

## GameRGBColor / GameRGBAColor - 颜色对象

完整的颜色类，支持颜色运算。所有分量范围 0-1。

```typescript
// RGB
new GameRGBColor(r, g, b)
GameRGBColor.random(): GameRGBColor   // 随机颜色（静态）

// RGBA
new GameRGBAColor(r, g, b, a)
```

| 方法 | 说明 |
|------|------|
| `set(r, g, b)` / `set(r, g, b, a)` | 设置颜色值，返回自身 |
| `clone()` | 克隆，返回新颜色 |
| `copy(c)` | 复制另一个颜色到自身 |
| `add(c)` | 颜色相加，返回新颜色 |
| `sub(c)` | 颜色相减，返回新颜色 |
| `mul(c)` | 颜色相乘，返回新颜色 |
| `div(c)` | 颜色相除，返回新颜色 |
| `addEq(c)` / `subEq(c)` / `mulEq(c)` / `divEq(c)` | 运算并覆盖自身 |
| `lerp(c, t)` | 插值，t=0 返回自身，t=1 返回 c |
| `equals(c)` | 近似相等（容差 0.000001） |
| `toRGBA()` | RGB → RGBA（alpha=1）（仅 GameRGBColor） |
| `blendEq(rgb)` | RGBA 与背景色叠加，返回最终颜色（仅 GameRGBAColor） |
| `toString()` | 格式化字符串 |

```javascript
// 使用 RGB 255 创建颜色
function rgb(r, g, b) {
  return new GameRGBColor(r / 255, g / 255, b / 255);
}
const red = rgb(255, 0, 0);

// 随机颜色
entity.meshColor = GameRGBColor.random();

// 颜色插值（渐变动画）
const startColor = new GameRGBColor(1, 0, 0);  // 红
const endColor = new GameRGBColor(0, 0, 1);    // 蓝
const midColor = startColor.lerp(endColor, 0.5); // 中间色

// RGBA 半透明
const semiRed = new GameRGBAColor(1, 0, 0, 0.5);

// 转换
const rgba = red.toRGBA();  // GameRGBColor → GameRGBAColor
```

---

## Sound - 音效对象

`entity.sound()` 和 `world.sound()` 的返回值，用于控制正在播放的音效。

| 方法 | 参数 | 说明 |
|------|------|------|
| `resume(currentTime?)` | currentTime?: number | 继续播放（可从指定时间点） |
| `pause()` | - | 暂停播放 |
| `stop()` | - | 终止播放 |
| `setCurrentTime(t)` | t: number | 跳转到指定时间点 |

```javascript
// 播放音效并保存 Sound 对象
const sound = entity.sound({ name: 'bgm_battle', volume: 0.8 });

// 暂停 / 继续
sound.pause();
sound.resume();

// 从第5秒继续播放
sound.resume(5);

// 跳转到第10秒
sound.setCurrentTime(10);

// 停止
sound.stop();
```
