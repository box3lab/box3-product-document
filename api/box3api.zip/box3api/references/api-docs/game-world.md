# GameWorld - 速查表

GameWorld 管理整个游戏世界。通过全局 `world` 对象访问。

## 属性速查

| 属性 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `projectName` | string | 地图名称 | `world.projectName` |
| `serverId` | string | 服务器ID | `world.serverId` |
| `currentTick` | number | 时钟计数 | `world.currentTick` |
| `entities` | Entity[] | 所有实体 | `world.entities` |
| `player` | PlayerEntity | 玩家 | `world.player` |
| `gravity` | number | 重力 | `world.gravity = 10` |
| `airFriction` | number | 空气阻力 | `world.airFriction = 0.1` |
| `maxFog` | number | 雾量 | `world.maxFog = 100` |
| `fogColor` | Color | 雾颜色 | `world.fogColor = 0xFFFFFF` |
| `rainDensity` | 0-1 | 雨密度 | `world.rainDensity = 0.5` |
| `snowDensity` | 0-1 | 雪密度 | `world.snowDensity = 0` |
| `sunDirection` | [x,y,z] | 太阳方向 | `world.sunDirection` |
| `ambientSound` | GameSoundEffect | 背景音乐 | `world.ambientSound.sample = 'audio/bgm.mp3'` |
| `playerJoinSound` | GameSoundEffect | 玩家加入音效 | `world.playerJoinSound.sample = '...'` |
| `playerLeaveSound` | GameSoundEffect | 玩家离开音效 | |
| `placeVoxelSound` | GameSoundEffect | 放置方块音效 | |
| `breakVoxelSound` | GameSoundEffect | 破坏方块音效 | |
| `globalData` | Storage | 全局数据 | `world.globalData.set('key', value)` |

## 方法速查

| 方法 | 说明 | 示例 |
|------|------|------|
| `createEntity(opts)` | 创建实体（上限时返回 null）| `world.createEntity({...})` |
| `querySelector(sel)` | 选择器查询，返回第一个匹配 | `world.querySelector('[tag=enemy]')` |
| `querySelectorAll(sel)` | 选择器查询，返回全部匹配 | `world.querySelectorAll('[tag=enemy]')` |
| `searchBox(bounds)` | 范围查询，参数为 GameBounds3 | `world.searchBox(bounds)` |
| `raycast(origin, direction, options?)` | 射线检测 | `world.raycast(pos, dir)` |
| `entityQuota()` | 剩余可创建实体数 | `world.entityQuota()` |
| `say(msg)` | 广播消息 | `world.say('Game started!')` |
| `sound(opts)` | 播放音效 | `world.sound({name: 'boom'})` |
| `animate(frames, opts)` | 全局动画 | `world.animate([{...}])` |
| `addCollisionFilter(selA, selB)` | 禁用两组实体间碰撞 | `world.addCollisionFilter('[tag=ghost]', '[tag=wall]')` |
| `removeCollisionFilter(selA, selB)` | 恢复碰撞 | `world.removeCollisionFilter('[tag=ghost]', '[tag=wall]')` |
| `clearCollisionFilters()` | 清空所有碰撞过滤 | `world.clearCollisionFilters()` |
| `addZone(config)` | 创建区域 | `world.addZone({...})` |
| `removeZone(zone)` | 删除区域 | `world.removeZone(zone)` |
| `teleport(mapId, players, serverId?)` | 传送到另一张地图 | `await world.teleport('map_id', [player])` |

## 事件速查

| 事件 | 触发条件 |
|------|---------|
| `onTick(cb)` | 每 64ms 触发（Tick更新） |
| `onPlayerJoin(cb)` | 玩家加入 |
| `onPlayerLeave(cb)` | 玩家离开 |
| `onChat(cb)` | 玩家聊天 |
| `onEntityCreate(cb)` | 实体创建 |
| `onEntityDestroy(cb)` | 实体销毁 |
| `onClick(cb)` | 玩家点击实体 |
| `onInteract(cb)` | 玩家互动实体 |

## 快速示例

### 初始化
```javascript
// 设置重力
world.gravity = 10;

// 设置天气
world.rainDensity = 0.5;
world.snowDensity = 0;

// 设置音乐（ambientSound 是 GameSoundEffect 对象，通过 .sample 赋值路径）
world.ambientSound.sample = 'audio/background_music.mp3';

// 广播消息
world.say('游戏已开始！');
```

### 创建实体
```javascript
const entity = world.createEntity({
  mesh: 'cube',
  position: [0, 5, 0],
  meshColor: 0xFF0000,
  mass: 1,
  gravity: true
});
```

### 查询实体
```javascript
// 选择器查询（按标签）
const enemies = world.querySelectorAll('[tag=enemy]');
const boss = world.querySelector('[tag=boss]');

// 范围查询（searchBox，参数是 GameBounds3）
const center = player.position;
const bounds = new GameBounds3(
  new GameVector3(center[0] - 10, center[1] - 10, center[2] - 10),
  new GameVector3(center[0] + 10, center[1] + 10, center[2] + 10)
);
const nearby = world.searchBox(bounds);

// 射线检测
const result = world.raycast(
  player.position,
  new GameVector3(0, 0, 1)  // +Z 方向
);
if (result) {
  console.log('射线碰到了:', result.entity || result.voxel);
}
```

### 禁用碰撞
```javascript
// addCollisionFilter 参数是选择器字符串
world.addCollisionFilter('[tag=ghost]', '[tag=wall]');
world.addCollisionFilter('[tag=enemy]', '[tag=enemy]');

// 清空所有碰撞过滤
world.clearCollisionFilters();
```

### 监听事件
```javascript
// 玩家加入时
world.onPlayerJoin((newPlayer) => {
  world.say('欢迎 ' + newPlayer.name + '！');
  newPlayer.position = [0, 10, 0];  // 传送到出生点
});

// 实体创建时
world.onEntityCreate((entity) => {
  if (entity.hasTag('boss')) {
    world.say('BOSS 出现！');
  }
});

// 每个Tick
world.onTick(() => {
  if (world.currentTick % 20 === 0) {  // 每1.28秒
    // 定期检查
  }
});
```

### 游戏管理
```javascript
class GameManager {
  constructor() {
    this.wave = 0;
    world.onPlayerJoin((p) => this.handlePlayerJoin(p));
    world.onTick(() => this.update());
  }
  
  handlePlayerJoin(player) {
    world.say('欢迎 ' + player.name);
    player.position = [0, 10, 0];
  }
  
  update() {
    const enemies = world.querySelectorAll('[tag=enemy]');
    if (enemies.length === 0) {
      this.nextWave();
    }
  }
  
  nextWave() {
    this.wave++;
    world.say('第 ' + this.wave + ' 波敌人！');
  }
}

const game = new GameManager();
```


---

## 客户端独有属性

以下属性仅在**客户端脚本**中的 `world` 对象上可用：

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `rendering3d` | boolean | true | 是否渲染 3D 场景（false=暂停渲染，2D UI 不受影响） |

```javascript
// 暂停 3D 渲染（性能优化 / 截图定格 / 过场动画）
world.rendering3d = false;

// 恢复 3D 渲染
world.rendering3d = true;

// 常见场景：打开全屏菜单时暂停渲染
menuBtn.events.on('onClick', () => {
  world.rendering3d = false;
});
closeBtn.events.on('onClick', () => {
  world.rendering3d = true;
});
```
