# ClientScreen（全局对象：screen）

屏幕监听 API。监听屏幕尺寸变化，做 UI 自适应。

## 事件

| 事件 | 说明 |
|------|------|
| `screen.events.add('resize', handler)` | 监听屏幕尺寸变化，handler 接收 `{ screenWidth: number, screenHeight: number }` |

## 全局变量

| 变量 | 类型 | 说明 |
|------|------|------|
| `screenWidth` | `number` | 当前屏幕宽度（像素）(只读) |
| `screenHeight` | `number` | 当前屏幕高度（像素）(只读) |

## 示例

```javascript
// 监听屏幕尺寸变化
screen.events.add('resize', ({ screenWidth, screenHeight }) => {
  console.log('新尺寸:', screenWidth, screenHeight);
  scaleUI(screenWidth, screenHeight);
});

// UI 自适应缩放
function scaleUI(w, h) {
  const box = ui.findChildByName('main_panel');
  if (!box.uiScale) box.uiScale = UiScale.create();
  box.uiScale.scale = w < 1300 ? w / 1300 : 1;
}

// 进入游戏时初始化一次
scaleUI(screenWidth, screenHeight);

// 直接读取当前屏幕宽高（全局变量）
console.log(screenWidth, screenHeight);
```
