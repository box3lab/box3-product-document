# GameAnimation 速查表

## 属性

| 属性 | 类型 | 说明 | 读写 |
|------|------|------|------|
| `currentTime` | `number` | 当前播放时间（帧数） | 读写 |
| `playState` | `GameAnimationPlaybackState` | 播放状态：PENDING/RUNNING/PAUSED/FINISHED | 只读 |
| `playbackRate` | `number` | 播放速度（默认1，每tick）| 读写 |
| `startTime` | `number` | 动画开始时间（tick，默认0）| 读写 |
| `target` | `GameWorld \| GameEntity \| GamePlayerEntity` | 动画作用对象 | 只读 |

## 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `play()` | `playback?: AnimationPlaybackOptions` | `void` | 播放或恢复动画 |
| `cancel()` | - | `void` | 暂停动画 |

## 关键帧参数（entity.animate() 的参数对象）

| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `duration` | `number` | ✓ | 帧时长（毫秒） |
| `position` | `[x, y, z]` | - | 位置坐标 |
| `meshOrientation` | `Quaternion` | - | 旋转（四元数）|
| `meshScale` | `[x, y, z]` | - | 缩放 |
| `meshColor` | `Color` | - | 颜色（16进制数） |
| `meshEmissive` | `number` | - | 发光度 |

## animate() 的 options 参数

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `repeat` | `number` | `0` | 重复次数（-1=无限，0=播一次） |
| `delay` | `number` | `0` | 延迟开始（毫秒） |
| `direction` | `'normal' \| 'reverse' \| 'alternate'` | `'normal'` | 播放方向 |

## 示例代码

```javascript
// 基础移动动画
const anim = entity.animate([
  { duration: 1000, position: [0, 5, 0] },
  { duration: 1000, position: [10, 5, 0] },
  { duration: 1000, position: [10, 5, 10] }
], { repeat: -1 });

// 控制动画
anim.cancel();              // 暂停
anim.play();                // 继续
anim.playbackRate = 2;      // 2倍速播放

// 颜色变换动画
entity.animate([
  { duration: 500, meshColor: 0xFF0000 },
  { duration: 500, meshColor: 0x0000FF }
], { repeat: -1, direction: 'alternate' });

// 入场动画（缩放）
entity.animate([
  { duration: 0, meshScale: [0, 0, 0] },
  { duration: 600, meshScale: [1, 1, 1] }
]);

// 查询播放状态
console.log(anim.playState);  // RUNNING / PAUSED / FINISHED
console.log(anim.currentTime); // 当前帧数
```

