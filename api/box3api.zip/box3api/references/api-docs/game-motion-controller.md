# GameMotionController 速查表

## 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `loadByName(configs)` | `string \| GameMotionConfig[] \| GameMotionClipConfig` | `GameMotionHandler` | 加载动作，返回处理器 |
| `pause()` | - | `void` | 暂停当前动作 |
| `resume()` | - | `void` | 恢复动作 |
| `setDefaultMotionByName(motionName?)` | `string \| undefined` | `void` | 设置默认循环动作（不传参=清空） |

## GameMotionHandler 方法

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `play()` | - | `void` | 播放动作 |
| `cancel()` | - | `void` | 中断动作（触发 onFinish） |
| `onFinish(handler)` | `(handler: GameMotionHandler) => void` | `GameMotionHandler` | 监听动作结束（支持链式调用） |

## GameMotionHandler 属性

| 属性 | 类型 | 说明 | 读写 |
|------|------|------|------|
| `target` | `GameEntity` | 所属实体 | 只读 |

## 配置接口

### GameMotionConfig
```typescript
{
  name: string,           // 动作名
  iterations?: number     // 重复次数（Infinity=无限循环）
}
```

### GameMotionClipConfig
```typescript
{
  motions: (string | GameMotionConfig)[],  // 动作序列
  iterations?: number                      // 序列重复次数
}
```

## 示例代码

```javascript
const npc = world.querySelector('#npc');

// 播放单个动作
const motion = npc.motion.loadByName('wave');
motion.onFinish(() => world.say('动作已结束'));
motion.play();

// 播放动作序列（依次执行）
const seq = npc.motion.loadByName({
  motions: ['walk', 'run', 'idle'],
  iterations: 2  // 整个序列重复2次
});
seq.play();

// 带重复配置的单个动作
const loop = npc.motion.loadByName({
  name: 'wave',
  iterations: Infinity  // 无限循环
});
loop.play();

// 设置默认循环动作（空闲时自动播放）
npc.motion.setDefaultMotionByName('idle');

// 清除默认动作
npc.motion.setDefaultMotionByName();

// 暂停/恢复当前播放
npc.motion.pause();
npc.motion.resume();

// 链式调用
npc.motion
  .loadByName('attack')
  .onFinish(() => {
    npc.motion.loadByName('idle').play();
  })
  .play();
```

