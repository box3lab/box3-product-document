# ClientNavigator（全局对象：navigator）

客户端设备信息 API。获取客户端设备类型、屏幕分辨率、语言等信息。

## 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `userAgent` | `string` (只读) | 客户端用户代理字符串 |
| `language` | `string` (只读) | 用户首选语言（如 "en"、"zh-CN"） |

## 方法

| 方法 | 返回类型 | 说明 |
|------|---------|------|
| `getDeviceInfo()` | `DeviceInfo` | 获取设备类型和屏幕分辨率 |

### DeviceInfo 接口

```typescript
{
  deviceType: 'Desktop' | 'Mobile',
  screen: {
    width: number,
    height: number
  }
}
```

## 示例

```javascript
// 获取设备信息
const info = navigator.getDeviceInfo();
console.log(info.deviceType);    // 'Desktop' 或 'Mobile'
console.log(info.screen.width);  // 屏幕宽度（像素）
console.log(info.screen.height); // 屏幕高度（像素）

// 获取用户语言
console.log(navigator.language); // 如 'zh-CN'

// 根据设备类型调整 UI
if (info.deviceType === 'Mobile') {
  // 移动端：放大按钮
} else {
  // 桌面端：正常大小
}
```
