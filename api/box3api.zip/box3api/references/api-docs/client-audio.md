# Audio 音频播放 API

## 概述

客户端音频播放 API（仅在客户端脚本中使用）。`Audio` 类用于播放背景音乐、音效等。

## 构造函数

```javascript
new Audio(src: string)
```

参数：
- `src` (string) — 音频文件路径（仅支持白名单 URL）

**项目内音频路径示例**：
```javascript
'https://static.dao3.fun/block/' + hash
```

## Audio 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `src` | string | 音频文件路径 |
| `volume` | number | 音量大小 (0-1，受玩家主音量控制) |
| `error` | MediaError \| null | 播放错误信息（null 表示无错误） |

## Audio 方法

| 方法 | 返回值 | 说明 |
|------|--------|------|
| `play()` | Promise\<void\> | 播放音频（可用 await）|
| `pause()` | void | 暂停播放 |
| `load()` | void | 预加载音频文件 |

## MediaError 错误码

当 `audio.error` 不为 null 时，检查 `error.code`：

| 错误码 | 说明 |
|--------|------|
| 1 | 播放被中止（MEDIA_ERR_ABORTED） |
| 2 | 网络错误（MEDIA_ERR_NETWORK） |
| 3 | 解码错误（MEDIA_ERR_DECODE） |
| 4 | 不支持的格式（MEDIA_ERR_SRC_NOT_SUPPORTED） |

## 示例代码

```javascript
// 预加载并播放背景音乐
const bgm = new Audio('https://static.dao3.fun/block/QmSkEpcxqFYvZNwZg...');
bgm.volume = 0.5;
bgm.load();  // 提前加载（可选）
bgm.play();

// 点击按钮播放音效
btn.events.on('onClick', async () => {
  const sfx = new Audio('https://static.dao3.fun/block/QmXxx...');
  sfx.volume = 0.8;
  await sfx.play();
  world.say('音效已播放！');
});

// 错误处理
const audio = new Audio('https://static.dao3.fun/block/invalid...');
try {
  await audio.play();
} catch (err) {
  if (audio.error) {
    console.log('音频加载失败，错误码:', audio.error.code);
  }
}

// 暂停音乐
bgm.pause();

// 多个音效同时播放
const sounds = [
  new Audio('https://static.dao3.fun/block/sfx1...'),
  new Audio('https://static.dao3.fun/block/sfx2...'),
  new Audio('https://static.dao3.fun/block/sfx3...')
];

sounds.forEach(s => {
  s.volume = 0.6;
  s.play();
});
```

## 注意事项

- `volume` 属性的音量最终受玩家系统主音量控制
- `play()` 返回 Promise，使用 `await` 确保播放完成后再继续
- 同一个 Audio 对象可以多次调用 `play()` 和 `pause()`
- 音频文件必须来自白名单 URL（如 `static.dao3.fun`）

