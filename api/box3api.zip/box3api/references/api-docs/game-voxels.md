# GameVoxels 速查表

## 概览

全局对象 `voxels` 用于读写游戏地图中的方块。支持方块类型、旋转、批量操作。

## 属性

| 属性 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `shape` | GameVector3（只读） | 地图尺寸，固定为 [127, 127, 127] | `voxels.shape.x` → 127 |
| `VoxelTypes` | string[]（只读） | 所有可用方块名称数组 | `voxels.VoxelTypes[0]` → 'air' |

## 方法

| 方法 | 签名 | 说明 |
|------|------|------|
| `id()` | `id(name: string): number` | 方块名称转 ID |
| `name()` | `name(id: number): string` | 方块 ID 转名称 |
| `setVoxel()` | `setVoxel(x, y, z, voxel, rotation?): number` | 放置方块（voxel 可为名称或 ID，rotation 0-3，用 'air' 删除） |
| `setVoxelId()` | `setVoxelId(x, y, z, voxel: number): number` | 用 ID 放置方块（ID 已含旋转码） |
| `getVoxel()` | `getVoxel(x, y, z): number` | 获取方块 ID（不含旋转码） |
| `getVoxelId()` | `getVoxelId(x, y, z): number` | 获取方块 ID（含旋转码） |
| `getVoxelRotation()` | `getVoxelRotation(x, y, z): number` | 获取旋转码（0-3） |

## 旋转码说明

```
方块ID + 16384 * 旋转次数
```

每次旋转代表顺时针 90 度。例如：`stoneID + 16384 * 2` 表示旋转 180 度的石块。

## 示例代码

```javascript
// 清空区域
for (let x = 0; x < 127; x++)
  for (let z = 0; z < 127; z++)
    for (let y = 9; y < 127; y++)
      voxels.setVoxel(x, y, z, 'air');

// 填满地面
for (let x = 0; x < 127; x++)
  for (let z = 0; z < 127; z++)
    voxels.setVoxel(x, 8, z, 'snow');

// 实心矩形
function cubefill(vox, sx, sy, sz, xsize, ysize, zsize) {
  for (let x = sx; x < sx+xsize; x++)
    for (let y = sy; y < sy+ysize; y++)
      for (let z = sz; z < sz+zsize; z++)
        voxels.setVoxel(x, y, z, vox);
}
cubefill('stone', 64, 9, 64, 10, 5, 10);

// 实心球体
function sphere(vox, cx, cy, cz, radius) {
  for (let x = cx-radius; x <= cx+radius; x++)
    for (let y = cy-radius; y <= cy+radius; y++)
      for (let z = cz-radius; z <= cz+radius; z++)
        if (Math.round(Math.sqrt((x-cx)**2+(y-cy)**2+(z-cz)**2)) <= radius)
          voxels.setVoxel(x, y, z, vox);
}
sphere('stone', 63, 24, 63, 12);
```

