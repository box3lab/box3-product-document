# Box3 已知坑点

## event-token-cancel：事件监听返回 token，注销用 `.cancel()` 不是 `.dispose()`

**症状**：调用 `token.dispose()` 报错找不到方法，监听器无法注销，多次绑定后同一事件触发多次。

**正确做法**：
```javascript
// ✓ 保存 token，用 cancel() 注销
const token = entity.onClick(() => { world.say('clicked'); });
token.cancel();    // 注销监听
token.resume();    // 恢复监听（如果只是暂停）
token.active();    // 检查是否活动中
```

---

## storage-async：storage 所有方法都是 async，必须 await

**症状**：`storage.getDataStorage('x').get('key')` 拿到的是 Promise 不是值，直接用会是 undefined 或 `[object Promise]`。

**正确做法**：
```javascript
// ✓ 必须 await
const space = storage.getDataStorage('players');
const data = await space.get('player_001');
await space.set('player_001', { score: 100 });
await space.increment('kill_count');
```

---

## create-entity-null：createEntity 到上限时返回 null，不检查直接崩

**症状**：地图实体数量达到上限后，`world.createEntity(...)` 返回 null，紧接着调用 `.addTag()` 等方法直接抛错。

**正确做法**：
```javascript
// ✓ 检查返回值
const entity = world.createEntity({ mesh: 'cube', position: [0, 5, 0] });
if (!entity) {
  console.log('实体数量达到上限，无法创建');
  return;
}
entity.addTag('enemy');
```

---

## voxel-id-rotation：方块 id 含旋转码，直接 `===` 判断方块类型会出错

**症状**：`getVoxelId()` 返回的 id 包含旋转码，同一种方块因朝向不同 id 不同，导致 `id === 125` 只能匹配特定朝向。

**正确做法**：
```javascript
// ✗ 错误：id 包含旋转码
if (voxels.getVoxelId(x, y, z) === 125) { ... }

// ✓ 方法1：用 getVoxel（不含旋转码）
if (voxels.getVoxel(x, y, z) === 125) { ... }

// ✓ 方法2：用 name() 转换
if (voxels.name(voxels.getVoxelId(x, y, z)) === 'dirt') { ... }

// ✓ 方法3：取模 16384 去掉旋转码
if (voxels.getVoxelId(x, y, z) % 16384 === 125) { ... }
```

---

## setvoxel-rotation-param：setVoxel 中 voxel 参数的旋转码无效

**症状**：`setVoxel(x, y, z, 16509)` 想放"朝东的泥土"，但实际旋转由 rotation 参数决定，voxel 里带的旋转码被忽略。

**正确做法**：
```javascript
// ✗ voxel 参数里的旋转码不生效
voxels.setVoxel(x, y, z, 16509);  // 想要旋转1次

// ✓ 用 rotation 参数控制旋转（0-3，每次顺时针90度）
voxels.setVoxel(x, y, z, 'dirt', 1);  // 旋转1次（朝东）

// ✓ 或用 setVoxelId（id 里的旋转码有效）
voxels.setVoxelId(x, y, z, 16509);  // 这个方法旋转码有效
```

---

## client-audio-url：ClientAudio 不支持项目内音频路径，只支持白名单 URL

**症状**：`new Audio('sounds/bgm.mp3')` 无法播放，报错或静默失败。

**正确做法**：
```javascript
// ✗ 不支持相对路径
const audio = new Audio('sounds/bgm.mp3');

// ✓ 使用白名单 URL
const audio = new Audio('https://static.dao3.fun/block/QmXxxxHashxxx');
// 技巧：在编辑器里复制音频文件的 Hash，拼接到这个前缀后面

await audio.play();
```

---

## storage-scope：getDataStorage 只限本地图，副图用 getGroupStorage

**症状**：在副图里用 `storage.getDataStorage('players')` 读不到主图的数据，两边是完全隔离的存储空间。

**正确做法**：
```javascript
// 单地图：只有本图能读写
const localSpace = storage.getDataStorage('local_data');

// 主副图共享：主图和副图都能读写同一份数据
const sharedSpace = storage.getGroupStorage('shared_data');
```

---

## http-whitelist：http.fetch 只支持白名单网址，失败不一定报错

**症状**：请求非白名单网址时请求直接超时或返回失败，没有明确错误信息。

**正确做法**：
```javascript
// ✓ 始终检查 res.ok
try {
  const res = await http.fetch('https://api.example.com/data');
  if (!res.ok) {
    console.log('请求失败，状态码:', res.status);
    return;
  }
  const data = await res.json();
} catch (err) {
  console.log('请求异常（可能是非白名单网址）:', err);
}
```

---

## position-array-assign：修改 position 数组元素可能不同步，应整体赋值

**症状**：`entity.position[0] = 10` 视觉上没有移动，或物理状态与显示不一致。

**正确做法**：
```javascript
// ✗ 直接修改数组元素，物理引擎可能不感知
entity.position[0] = 10;

// ✓ 整体赋值
entity.position = [10, entity.position[1], entity.position[2]];
// 或
const pos = entity.position;
entity.position = [10, pos[1], pos[2]];
```

---

## motion-name-not-found：setDefaultMotionByName 动作名不存在时抛错

**症状**：`entity.motion.setDefaultMotionByName('walk')` 动作名写错时，方法静默无效并抛出错误，但不会告诉你正确的名称。

**正确做法**：
```javascript
// ✓ 先确认实体上存在该动作名（在编辑器里查看模型的动作列表）
entity.motion.setDefaultMotionByName('idle');   // 存在的动作名
entity.motion.setDefaultMotionByName();          // 传 undefined = 清空默认动作

// 注意：传空字符串 '' 也会报错
entity.motion.setDefaultMotionByName('');  // ✗ 报错
```

---

## ambient-sound-type：ambientSound 是 GameSoundEffect 对象，不是字符串

**症状**：`world.ambientSound = 'audio/bgm.mp3'` 直接赋字符串，音乐无法播放或报错。

**正确做法**：
```javascript
// ✗ 错误：不能直接赋字符串
world.ambientSound = 'audio/bgm.mp3';

// ✓ 正确：通过 .sample 属性赋值
world.ambientSound.sample = 'audio/bgm.mp3';

// 也可以设置更多参数
world.ambientSound.sample = 'audio/bgm.mp3';
world.ambientSound.gain = 0.8;   // 音量增益
```

同样适用于 `playerJoinSound`、`playerLeaveSound`、`placeVoxelSound`、`breakVoxelSound`。

---

## ui-create-method：UI 节点用 create()，不是 new

**症状**：`new UiBox()` 报错，UI 节点无法创建。

**正确做法**：
```javascript
// ✗ 错误：Box3 UI 不支持 new 构造
const box = new UiBox();

// ✓ 正确：使用静态工厂方法
const box    = UiBox.create();
const text   = UiText.create();
const img    = UiImage.create();
const inp    = UiInput.create();
const scroll = UiScrollBox.create();
```

节点创建后需要设置 `parent` 才会被渲染：
```javascript
box.parent = ui;  // 挂到根节点
```

---

## quaternion-constructor-order：GameQuaternion 构造函数参数顺序是 w,x,y,z

**症状**：手写 `new GameQuaternion(x, y, z, w)` 旋转方向错误，以为是"先xyz后w"。

**正确做法**：
```javascript
// ✗ 以为是 (x, y, z, w)
const q = new GameQuaternion(0, 0, 0, 1);  // 这是错的！

// ✓ 实际参数顺序是 (w, x, y, z)，w 实部在前
const q = new GameQuaternion(1, 0, 0, 0);  // 恒等旋转

// 推荐：用工厂方法避免混淆
entity.meshOrientation = GameQuaternion.fromEuler(0, Math.PI / 2, 0);
entity.meshOrientation = GameQuaternion.fromAxisAngle(axis, rad);
```

另外，旋转组合方法名是 `mul()`，不是 `multiply()`；逆旋转是 `inv()`，不是 `inverse()`。
