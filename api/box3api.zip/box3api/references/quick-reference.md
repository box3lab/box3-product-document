# Box3 API 快速参考

## 全局对象速查

### world（GameWorld）

| 功能 | API |
|------|-----|
| 创建实体（上限时返回 null）| `world.createEntity({ mesh, position, ... })` |
| 获取所有实体 | `world.entities` |
| 选择器查询（第一个）| `world.querySelector('[tag=enemy]')` |
| 选择器查询（全部）| `world.querySelectorAll('[tag=enemy]')` |
| 范围查询 | `world.searchBox(new GameBounds3(lo, hi))` |
| 射线检测 | `world.raycast(origin, direction)` |
| 广播消息 | `world.say(message)` |
| 播放音效 | `world.sound({ sample: 'audio/x.mp3' })` |
| 获取全局数据 | `world.globalData.get(key)` |
| 保存全局数据 | `world.globalData.set(key, value)` |
| 背景音乐 | `world.ambientSound.sample = 'audio/bgm.mp3'` |
| 禁用两组实体间碰撞 | `world.addCollisionFilter('[tag=a]', '[tag=b]')` |
| 传送到另一张地图 | `await world.teleport('mapId', [player])` |

### player（GamePlayerEntity）

| 功能 | API |
|------|-----|
| 玩家昵称 | `player.name` |
| 玩家 ID | `player.id` |
| 用户 ID | `player.userId` |
| 位置 | `player.position` |
| 朝向 | `player.facingDirection` |
| 速度 | `player.velocity` |
| 允许跳跃 | `player.enableJump = true` |
| 允许飞行 | `player.canFly = true` |
| 行走速度 | `player.walkSpeed` |
| 保存玩家数据 | `player.data.set(key, value)` |
| 读取玩家数据 | `player.data.get(key)` |
| 设置相机模式 | `player.cameraMode = 'FPS'` |
| 垂直视场角 | `player.cameraFovY = 75` |

---

## GameEntity 属性速查

### 外观

```javascript
entity.position = [x, y, z]
entity.meshOrientation = GameQuaternion.fromEuler(0, Math.PI/2, 0)
entity.meshScale = [1, 1, 1]
entity.meshColor = 0xFF0000          // 十六进制颜色
entity.meshInvisible = true
entity.meshEmissive = 0.5            // 发光度 0-1
entity.meshMetalness = 0.8           // 金属感 0-1
entity.meshShininess = 0.5           // 反光度 0-1
entity.customName = '显示的名字'
entity.showEntityName = true
```

### 物理

```javascript
entity.mass = 1.0                    // 0 = 固定不动
entity.velocity = [vx, vy, vz]
entity.gravity = true
entity.collides = true
entity.fixed = false
entity.friction = 0.5                // 0=滑, 1=粘
entity.restitution = 0.5             // 0=软, 1=弹
// entity.bounds 是只读的 GameVector3，不可直接赋值
entity.entityContacts                // 当前接触的实体[]（只读）
entity.voxelContacts                 // 当前接触的方块[]（只读）
```

### 交互

```javascript
entity.enableInteract = true
entity.interactRadius = 3.0
entity.interactHint = '按 E 交互'
entity.interactColor = 0x00FF00
```

### 战斗

```javascript
entity.hp = 100
entity.maxHp = 100
entity.enableDamage = true
entity.showHealthBar = true
entity.destroyed                     // 只读
```

### 粒子

```javascript
entity.particleRate = 10             // 每秒粒子数
entity.particleLimit = 100
entity.particleLifetime = 2.0
entity.particleColor = [0xFF0000]
entity.particleVelocity = [0, 2, 0]
entity.particleAcceleration = [0, -1, 0]
```

---

## GameEntity 方法速查

| 方法 | 说明 |
|------|------|
| `entity.lookAt(pos)` | 面向位置 |
| `entity.animate(keyframes, opts)` | 关键帧动画 |
| `entity.getAnimations()` | 获取所有动画 |
| `entity.sound({ sample, gain, radius })` | 播放声音，返回 Sound 对象 |
| `entity.say(message)` | 实体说话 |
| `entity.addTag(tag)` | 添加标签 |
| `entity.removeTag(tag)` | 移除标签 |
| `entity.hasTag(tag)` | 检查标签 |
| `entity.tags()` | 获取所有标签（注意是方法，加括号）|
| `entity.hurt(damage)` | 造成伤害 |
| `entity.destroy()` | 销毁实体 |

---

## 事件监听速查

| 事件 | 触发时机 |
|------|---------|
| `entity.onClick(cb)` | 玩家点击 |
| `entity.onInteract(cb)` | 玩家按 E 互动 |
| `entity.onEntityContact(cb)` | 与实体碰撞开始 |
| `entity.onEntitySeparate(cb)` | 与实体碰撞结束 |
| `entity.onVoxelContact(cb)` | 与方块碰撞开始 |
| `entity.onVoxelSeparate(cb)` | 与方块碰撞结束 |
| `entity.onFluidEnter(cb)` | 进入液体 |
| `entity.onFluidLeave(cb)` | 离开液体 |
| `entity.onTakeDamage(cb)` | 受伤 — `{damage, attacker?}` |
| `entity.onDie(cb)` | 死亡 — `{attacker?}` |
| `entity.onDestroy(cb)` | 销毁时 |
| `world.onTick(cb)` | 每 64ms — `{tick}` |
| `world.onPlayerJoin(cb)` | 玩家加入 — `{entity}` |
| `world.onPlayerLeave(cb)` | 玩家离开 — `{entity}` |
| `world.onChat(cb)` | 聊天 — `{entity, message}` |
| `world.onEntityCreate(cb)` | 实体创建 |
| `world.onEntityDestroy(cb)` | 实体销毁 |

> **⚠️ 所有 on*() 返回 EventToken，注销用 `token.cancel()`**

---

## 数据结构速查

### GameQuaternion（旋转）

```javascript
// ⚠️ 构造函数参数顺序：w 在前
new GameQuaternion(w, x, y, z)

// 推荐：从欧拉角创建（旋转顺序 YZX）
GameQuaternion.fromEuler(x, y, z)    // 参数是弧度
GameQuaternion.fromAxisAngle(axis, rad)

// 旋转组合用 .mul()，不是 .multiply()
q1.mul(q2)
```

### GameBounds3（区域）

```javascript
const bounds = new GameBounds3(
  new GameVector3(0, 0, 0),    // lo（最小角）
  new GameVector3(10, 5, 10)   // hi（最大角）
);
world.searchBox(bounds)        // 范围查询实体
player.movementBounds = bounds // 限制玩家活动范围
```

### 颜色格式

```javascript
entity.meshColor = 0xFF0000        // 十六进制（推荐）
entity.meshColor = [255, 0, 0]     // RGB 数组 0-255
entity.meshColor = [1, 0, 0, 0.5]  // RGBA 数组 0-1
new GameRGBColor(r, g, b)          // 0-1 范围，用于玩家颜色
GameRGBColor.random()              // 随机颜色
```

### 音效对象（Sound）

```javascript
const s = entity.sound({ sample: 'audio/x.mp3', gain: 1.0 });
s.pause()
s.resume(currentTime?)
s.stop()
s.setCurrentTime(t)
```

---

## 数据存储速查

```javascript
// ⚠️ 所有方法都是 async，必须 await
const space = storage.getDataStorage('my_space');   // 单地图
const group = storage.getGroupStorage('shared');     // 主副图共享

await space.set('key', value)
const val = await space.get('key')          // 不存在返回 undefined
await space.update('key', (prev) => newVal) // 原子更新
await space.remove('key')
await space.increment('key', 1)             // 原子递增
const list = await space.list({ pageSize: 20, prefix: 'player_' })
```

---

## 方块操作速查

```javascript
voxels.setVoxel(x, y, z, 'stone')          // 放置方块（名称）
voxels.setVoxel(x, y, z, 'air')            // 删除方块
voxels.setVoxel(x, y, z, 'stone', 1)       // 旋转（0-3，顺时针90°）
voxels.setVoxelId(x, y, z, id)             // 用 ID 放置（旋转码有效）
voxels.getVoxel(x, y, z)                   // 获取方块ID（不含旋转码）
voxels.getVoxelId(x, y, z)                 // 获取方块ID（含旋转码）
voxels.name(id)                            // ID → 名称
voxels.id('stone')                         // 名称 → ID
```

---

## ClientUI 速查（客户端）

```javascript
// ⚠️ 创建用 create()，不是 new
const box   = UiBox.create();
const text  = UiText.create();
const img   = UiImage.create();
const inp   = UiInput.create();

// 挂载（必须设置 parent 才渲染）
box.parent = ui;

// 文本
text.textContent = 'Score: 0';
text.textFontSize = 24;
text.textXAlignment = 'Center';     // 非 textAlign
text.autoWordWrap = true;           // 非 textWrap

// 图片
img.image = 'picture/icon.png';
img.imageDisplayMode = ImageDisplayMode.Contain;  // 非 imageFit

// 事件（用 pointerdown，不是 onClick）
btn.events.add('pointerdown', ({ target }) => { ... });

// 鼠标锁定
input.lockPointer();
input.unlockPointer();
```

---

## 常用示例

### 创建可拾取物品

```javascript
const item = world.createEntity({
  mesh: 'cube',
  position: [5, 2, 0],
  meshColor: 0xFFD700,
  mass: 1,
  enableInteract: true,
  interactRadius: 3,
  interactHint: '拾取',
});

item.onInteract((event) => {
  world.say(event.player.name + ' 拾取了物品！');
  item.destroy();
});
```

### 计分系统

```javascript
// ⚠️ 存到 player.data，不要存到实体属性
await player.data.set('score', 0);

async function addScore(points) {
  await player.data.update('score', (prev) => (prev || 0) + points);
  const score = await player.data.get('score');
  world.say('Score: ' + score);
}

enemy.onDestroy(() => addScore(10));
```

### 检测是否在地面

```javascript
let onGround = false;
const t1 = player.onVoxelContact(() => { onGround = true; });
const t2 = player.onVoxelSeparate(() => { onGround = false; });
// 清理：t1.cancel(); t2.cancel();
```

---

## 坐标系

- **X+** 向右，**Y+** 向上，**Z+** 向后（背向玩家初始朝向）
- 单位：游戏单位（约等于 1 米）
- 1 Tick = 64ms

## 性能提示

- 范围查询用 `world.searchBox(bounds)` 而不是遍历 `world.entities`
- 高频事件（onEntityContact 等）中避免做重计算
- 粒子总数上限约 2000，单实体 particleLimit 建议 ≤ 500
